package cadenzanea;
 //imports for JAVA FX and all other methods
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.*;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.image.ImageView;
import javafx.stage.*;
import javafx.util.Duration;
import javax.sound.sampled.*;


public class FXMLDocumentController implements Initializable {
    /*Variables & Objects 
    section*/
    RecTools RT = new RecTools(); /*builds instance of recording tools class    
                                              to handle functions to do with recording*/
  
    AudioFormat audioFormat = RT.getAudioFormat(); /*returns the details of the audio format 
                                                   needed for project from recording tools*/
    
    FileChooser fileChooser; /* Sets up file chooser to allow for navigation of windows explorer
                                                        for loading and saving*/
    
    //sets up target data line and mixer interface for recording
    TargetDataLine tau;
    Mixer mixer;
    
    //sets up file name variables which can be called upon during run time
    String fileName;
    String mergedFileName;
    
    //sets up int for channel selection.
    int channelSelected;
    
    //Files used during recording
    File recordedFileWAV;

    /*sets up boolean variables for basic control of system
    system starts up neither rcording or playing back so
    initialised as false*/
    
    private Boolean recordButtonActive = false;
    private Boolean playButtonActive = false;
    private Boolean fileSaved = false;

    
    
    
    /*Thread method 
    section*/
    
//Creates new thread which can be run via a method call
 private void startRecord() throws InterruptedException{
    Thread startRec = new Thread(() -> { 
        try {        
            RT.startRec(); //try to initiate recording
        } 
        catch (Exception ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex); //if failed log failure
        }   
    });
    startRec.start(); //start recording thread
    
  }
 //Creates new thread which can be run via a method call
 private void PlayThread() throws LineUnavailableException, IOException{
    Thread playBack = new Thread(()->{
    try{
        RT.startPlayback(audioFormat); //try to initiate playback
    } 
    catch (LineUnavailableException | IOException ex) {
         Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex); //if failed log fail
     }
   });
  playBack.start(); //start playback thread
}

 
 
 
   
    /*Regular Methods 
    section*/
    private static void configureFileChooser(final FileChooser fileChooser) {
            fileChooser.setInitialDirectory(new File(System.getProperty("user.home"))); //set default save path to users home drive
            
            fileChooser.getExtensionFilters().addAll( //add extension filters to only look for wav 
                                                      //files but also show all files when users change it
                    
                new FileChooser.ExtensionFilter("WAV", "*.wav"),
                new FileChooser.ExtensionFilter("All Files", "*.*")
                );
    }
    
    //*Animation Methods*//
    public void rotateClockwise(ImageView reel){ //insert imageview container
    RotateTransition rotation = new RotateTransition(Duration.millis(10000), reel); //sets up new rotation transition
    
    if(recordButtonActive == true||playButtonActive == true){ //if record or playback button is active
    rotation.setByAngle(360);                                 //Set rotation 360 degrees
    rotation.setCycleCount(Animation.INDEFINITE);             //continue animation continuously
    rotation.setInterpolator(Interpolator.LINEAR);            //linear movement
    rotation.play();                                          //play animation
    }
    else if(recordButtonActive == false||playButtonActive == false){ //if record or playback button isn't active
    rotation.setByAngle(0);                                          //Set rotation to 0 degrees (effectively stopping it)
    rotation.setCycleCount(Animation.INDEFINITE);                    //continue animation continuously
    rotation.setInterpolator(Interpolator.LINEAR);                   //linear movement
    rotation.play();                                                 //play animation
    }
    }
    public void rotateAntiClockwise(ImageView reel){ //esentially the same method with one key difference
    RotateTransition rotation = new RotateTransition(Duration.millis(10000), reel);
    if(recordButtonActive == true||playButtonActive == true){
    rotation.setByAngle(-360);                                  //only difference is here at set roation -360
    rotation.setCycleCount(Animation.INDEFINITE);               //creating an anticlockwise animation
    rotation.setInterpolator(Interpolator.LINEAR);
    rotation.play();
    }
    else if(recordButtonActive == false||playButtonActive == false){
    rotation.setByAngle(0);
    rotation.setCycleCount(Animation.INDEFINITE);
    rotation.setInterpolator(Interpolator.LINEAR);
    rotation.play();
    }
    }
    
    public File createWavDirectory(File audioFile){ //insert the variable that holds the file name
        
       if(audioFile == null){                       //if the file directory is empty
       fileChooser = new FileChooser();             //create a file chooser
       configureFileChooser(fileChooser);           //confiure file chooser using method
       
       fileChooser.setTitle("Select directory to save wav..."); //setup the file chooser name to be "Select directory to save wav..."
       fileChooser.setInitialFileName("Recording_"+new SimpleDateFormat("ddMMyyyy-HHmmss").format(Calendar.getInstance().getTime())+".wav");
       //sets initial file name to a dated file name that is unique based on time but can be changed
       
       Stage stage = (Stage) cadenzaMenuBar.getScene().getWindow(); //show file chooser window
       File tempWavFile = fileChooser.showSaveDialog(stage); //file directory is fetched from temp array from the file chooser
       recordedFileWAV = tempWavFile; //assign new directory to file variable
       }
       else if(audioFile != null) recordedFileWAV = RT.getFile(); //if the file input is empty, get the file name from the class   
       
       else RT.setFileName("errorInRecording_"+new SimpleDateFormat("ddMMyyyy-HHmmss").format(Calendar.getInstance().getTime())+".wav");
       //setup an error file directory if file is not created correctly
       
       return recordedFileWAV; //return the new file directory
    }
    
    /* all of these methods a follow the same formula*/ 
    
    public void cancelledSaveWarning(){
        Alert cancelledSave = new Alert(AlertType.WARNING);    //create new warning alert
       cancelledSave.setTitle("Didn't save audio");            //set warning title
       
       cancelledSave.setHeaderText("User cancelled save of audio or field is empty"); //set header text
       cancelledSave.setContentText("If you wish to keep this audio please save before re-recording"); //set main text
       cancelledSave.showAndWait(); //wait until alert is closed
    }
    
    public void contentReset(){
       Alert cancelledSave = new Alert(AlertType.WARNING);
       cancelledSave.setTitle("Program reset");
       cancelledSave.setHeaderText("Program has been reset");
       cancelledSave.showAndWait();
    }
    
    public void directoryNotSet(){
       Alert cancelledSave = new Alert(AlertType.WARNING);
       cancelledSave.setTitle("Directory not set");
       cancelledSave.setHeaderText("User cancelled directory set or field is empty");
       cancelledSave.setContentText("Please try again");
       cancelledSave.showAndWait();
    }
    
    public void directorySavedSucessfullyAlert(){
        Alert cancelledSave = new Alert(AlertType.CONFIRMATION); //create confirmation alert
       cancelledSave.setTitle("Saved directory");
       cancelledSave.setHeaderText("Audio File directory set correctly.");
       cancelledSave.setContentText("When saved your recording will be saved here: "+ (String)RT.getFileName());
       cancelledSave.showAndWait();
    }
    
    public void errorHandlingButtonMethod(){
        Alert cancelledSave = new Alert(AlertType.ERROR);
       cancelledSave.setTitle("Button Press State Error");
       cancelledSave.setContentText("Button press has failed to initiate");
       cancelledSave.showAndWait();
    }
    
    /*more complex alerts*/
    
    public void exitWithoutSavingAlert() throws IOException{
        Alert alert = new Alert(AlertType.CONFIRMATION);  //new confirmation alert
        alert.setTitle("Exiting program without saving"); //set title
        alert.setHeaderText("Attempting to exit without saving. If you meant to save, please press save and exit."); //set header text
        alert.setContentText("Please choose an option"); //set content text

        ButtonType saveAndExitButton = new ButtonType("Save and Exit"); //create buttons for input
        ButtonType exitWithoutSavingButton = new ButtonType("Exit without saving");
        ButtonType cancelButton = new ButtonType("Cancel", ButtonData.CANCEL_CLOSE); //set cancel button to cancel on press
        
        alert.getButtonTypes().setAll(saveAndExitButton, exitWithoutSavingButton, cancelButton); //insert buttons into alert
        
        Optional<ButtonType> result = alert.showAndWait(); //wait for button press or exit
        if (result.get() == saveAndExitButton){ //if the save and exit button pressed
            saveButtonMethod();                 //call save function
            handleExit();                       //then exit program
        } else if (result.get() == exitWithoutSavingButton) {
            handleExit();                       //exit program
        } 
        else {}
        
    }
    
    public void resetConfirmAlert() throws IOException{
        Alert alert = new Alert(AlertType.CONFIRMATION);    //new confirmation alert
        alert.setTitle("Resetting program without saving"); //set title
        alert.setHeaderText("Attempting to reset without saving. To stop this action, press no"); //set header text
        alert.setContentText("Please choose an option");    //set content text

        ButtonType yesButton = new ButtonType("Yes"); //create buttons for input
        ButtonType noButton = new ButtonType("No");
        
        
        alert.getButtonTypes().setAll(yesButton, noButton); //insert buttons into alert
        
        Optional<ButtonType> result = alert.showAndWait(); //wait for button press or exit
        if (result.get() == yesButton){ //if the yes button pressed
        resetMethod();                  //call the reset method
        }    

        else{}
        
    }
    
    
    
    public void saveButtonMethod() throws IOException{
       
       File wavFileAndDirectory = createWavDirectory(RT.getFile());
       if(wavFileAndDirectory == null)cancelledSaveWarning();
       
       else{
           fileSaved = true;
           RT.recordSave(wavFileAndDirectory);
       } 
       
    }
    public void saveSoloChannelButtonMethod(int channelSelected) throws IOException{
        RT.setActiveChannel(channelSelected);
        File wavFileAndDirectory = createWavDirectory(RT.getFile());
        
        if(wavFileAndDirectory == null)cancelledSaveWarning();
        else{
        RT.recordSaveOnlyChannelOne(recordedFileWAV, channelSelected);
        }
    }
    public void resetSoloChannelButtonMethod(int channelSelected) throws IOException{
        RT.setActiveChannel(channelSelected);
        RT.resetSingleArray();
        
    }
    
    
    
    public void resetMethod(){
        RT.intialiseValues();
        contentReset();
    }
    public void animationStartStop(){
        rotateClockwise(reelSupply);
        rotateAntiClockwise(reelTakeup);
    }
    
    //set directory method
    public void saveMenuSetFile(){
        File newDirectoryFile = RT.getFile(); //gets file name
        createWavDirectory(newDirectoryFile); //create directory method
        
        if(newDirectoryFile == null)directoryNotSet(); //call directory not set error if it's null
        
        else if(newDirectoryFile != null)directorySavedSucessfullyAlert(); //call directory set alert if not null
        
        else errorHandlingButtonMethod(); //if neither is true, call the button handling error
    }
    
    public void recordButtonMethod() throws InterruptedException, FileNotFoundException, LineUnavailableException, IOException{
    fileSaved = false;                      //file saved now false as new data not saved
    if(recordButtonActive == false){        //if when the button is pressed, it is not active
        
    recordButtonActive = true;              //recording then becomes active
    disableToggleButtons();                 //disable toggle buttons when recording active
    startRecord();                          //start the thread (therefore starting recording)
    playPauseButton.setDisable(true);       //disable the play button
    disableMenuItems();                     //disable file menus from being pressed
    
    animationStartStop();                   //start animation as recording active is true
    PlayThread();                           //Play the audio when recording so you can record with what's palying
    
    }
    else if(recordButtonActive == true){    //if when the button is pressed, it is active
        
    recordButtonActive = false;             //recording then becomes inactive
    playPauseButton.setDisable(false);      //enable the play button
    enableToggleButtons();                  //enable the toggle buttons
    enableMenuItems();                      //enable the menu items
    RT.recordPause();                       //pause the recording so it can be recorded to
    
    animationStartStop();                   //stop the animation as recording active is false
    RT.stopPlayback();                      //stop playing audio
    }
    else{
    errorHandlingButtonMethod();            //if putton press failed, return button handling error
    }    
    }
    
    public void stopButtonMethod() throws FileNotFoundException{
       recordButtonActive = false;          //record button active is set to false
       animationStartStop();                //stop animation as reording is now not active
       playPauseButton.setDisable(false);   //enable the play button
       RT.recordStop();                     //stop recording
       enableToggleButtons();               //enable toggle buttons
       enableMenuItems();                   //enable the menu items
       stopPlaybackMethod();                //call stop playback method
    }
    
    public void stopPlaybackMethod(){
        RT.stopPlayback();          //stop playback
	playButtonActive = false;   //set record button active to false
    }
    
    public void exitButtonMethod() throws IOException{
        if(fileSaved == false) exitWithoutSavingAlert(); //if file isn't saved 
                                                         //throw exit without saving alert
        
        else if(fileSaved == true) handleExit(); //if the file is saved, handle the exit
        
        else errorHandlingButtonMethod();        //if not throw button error method
    }
   
    public void handleExit(){
        Platform.exit(); //exit platform
        System.exit(0);  //exit system
    }
    
    public void playButtonMethod() throws InterruptedException, LineUnavailableException, IOException{
    if(playButtonActive == false){                  //if when the button is pressed, it is active
    playButtonActive = true;                        //set play button active to true
    animationStartStop();                           //start animation
    recordingPauseButton.setDisable(true);          //disable recording button 
    stopButton.setDisable(true);                    //disable stop button
    disableToggleButtons();                         //disable toogle button
    disableMenuItems();                             //disable menu items
    PlayThread();                                   //playback audio
    }
    else if(playButtonActive == true){          //if when the button is pressed, it is not active
    playButtonActive = false;                   //set play button active to false
    animationStartStop();                       //stop animation
    recordingPauseButton.setDisable(false);     //enable recording pause button
    stopButton.setDisable(false);               //enable stop button
    enableToggleButtons();                      //enable toggle buttons
    enableMenuItems();                          //enable menu items
    stopPlaybackMethod();                       //stop playing audio
    }
    else errorHandlingButtonMethod();           //if button press is not recognised, throw error message
     
    }
    
    public void toggleButtonMethod(){
        if(channelToggleGroup.getSelectedToggle() == toggleButton1){ //if toggle button is equal to given button
            RT.setChannel(1);                                        //set channel using method to channel toggle value
            channelSelectedLabel.setText("1");                       //set text to toggle value
                                   
        }
        else if(channelToggleGroup.getSelectedToggle() == toggleButton2){ //code repeated for each repeated channel
            RT.setChannel(2);
            channelSelectedLabel.setText("2");
            
        }
        else if(channelToggleGroup.getSelectedToggle() == toggleButton3){
            RT.setChannel(3);
            channelSelectedLabel.setText("3");
            
        }
        else if(channelToggleGroup.getSelectedToggle() == toggleButton4){
            RT.setChannel(4);
            channelSelectedLabel.setText("4");
            
        }
        else{                                                       //if there is an error reset channel to 1
            channelToggleGroup.selectToggle(toggleButton1);
            RT.setChannel(1);
        }
    }
    public void disableToggleButtons(){ //disable all toggle buttons on method call
        toggleButton1.setDisable(true);
        toggleButton2.setDisable(true);
        toggleButton3.setDisable(true);
        toggleButton4.setDisable(true);
    }
    public void enableToggleButtons(){ //enable all toggle buttons on method call
        toggleButton1.setDisable(false);
        toggleButton2.setDisable(false);
        toggleButton3.setDisable(false);
        toggleButton4.setDisable(false);
    }
    
    public void disableMenuItems(){ //disable all File menu items and slider controls
        saveMenuButton.setDisable(true);
        saveDirectoryMenuButton.setDisable(true);
        resetMenuButton.setDisable(true);
        resetOnly.setDisable(true);
        saveOnly.setDisable(true);
        panSlider.setDisable(true); //locks in slider values set before recording
        gainSlider.setDisable(true);
    }
    public void enableMenuItems(){ //enable all File menu items and slider controls
        saveMenuButton.setDisable(false);
        saveDirectoryMenuButton.setDisable(false);
        resetMenuButton.setDisable(false);
        resetOnly.setDisable(false);
        saveOnly.setDisable(false);
        panSlider.setDisable(false); //allows slider values to be changed again
        gainSlider.setDisable(false);
    }
    
    
    
    
    
    /*FXML methods 
    section*/
    @FXML Button recordingPauseButton; //sets up all GUI items
    @FXML Button playPauseButton;
    @FXML Button stopButton;
    @FXML MenuBar cadenzaMenuBar;
    @FXML private ImageView reelSupply;
    @FXML private ImageView reelTakeup;
    @FXML MenuItem saveMenuButton;
    @FXML MenuItem saveDirectoryMenuButton;
    @FXML MenuItem resetMenuButton;
    @FXML MenuItem exitMenuButton;
    @FXML Menu saveOnly;
    @FXML Menu resetOnly;
    @FXML Label channelSelectedLabel;
    @FXML Label panLabel;
    @FXML Label gainLabel;
    @FXML ToggleGroup channelToggleGroup;
    @FXML ToggleButton toggleButton1;
    @FXML ToggleButton toggleButton2;
    @FXML ToggleButton toggleButton3;
    @FXML ToggleButton toggleButton4;
    @FXML Slider panSlider;
    @FXML Slider gainSlider;
    
    
    //sets up @FXML button methods that can be simply referenced by using previously created complex methods
    //buttons need only call a single simple method that perfroms multiple actions
    
    @FXML private void recordingButtonAction(ActionEvent event) throws LineUnavailableException, InterruptedException, FileNotFoundException, IOException {
    recordButtonMethod(); //calls rcording button mehod
    }
    
    @FXML private void playButtonAction(ActionEvent event) throws InterruptedException, LineUnavailableException, IOException {
    playButtonMethod(); //calls play button method
    }
    
    @FXML private void stopButtonAction(ActionEvent event) throws FileNotFoundException, IOException{
    stopButtonMethod(); //calls stop button method
    }
    @FXML private void toggleButtonAction(ActionEvent Event){
    toggleButtonMethod(); //calls toogle button method
    }
    
    @FXML private void changePanSlider(){
    double value = panSlider.getValue(); //double value is equal to slider pan slider value 
    RT.setPanValue((float) value);       //sets value (cast to float) as pan value in RecTools object
    
    if(value == 0){                     //if value = 0  
    panLabel.setText("C");              //pan label text is set to C for Centre
    }
    else if(value < 0){                 //if value < 0
    panLabel.setText((value*100)+"L");  //pan label text is set to value*100 (to make it a whole number)
                                        //with L to signify left panning
    }
    else if(value > 0){                 //if value > 0
    panLabel.setText((value*100)+"R");  //pan label text is set to value*100 (to make it a whole number)
                                        //with R to signify right panning
    }
    else if(value == -1){               //if value = -1
    panLabel.setText("L");              //pan label text set to L to signify hard left panning
    }
    else if(value == 1){                //if value = 1
    panLabel.setText("R");              //pan label text set to R to signify hard right panning
    }
    }
    @FXML private void changeGainSlider(){  
    float value = (float)gainSlider.getValue(); //double value is equal to slider gain slider value                   
    RT.setGainValue(value);                     //sets value (cast to float) as gain value in RecTools object
    gainLabel.setText(value+" dB");             //set gain label text to the slider value + dB 
                                                //(to signify decibels, a measurement of volume) 
    }
    
    //*Menu Items*//
    @FXML private void saveButtonAction(ActionEvent event) throws IOException{
    saveButtonMethod(); //save button method called when button pressed
    }
    
    //* Save solo channel button methods called here*//
    @FXML private void saveSoloButtonAction1() throws IOException{
        channelSelected = 1;                            //set channel selected to 1
        saveSoloChannelButtonMethod(channelSelected);   //call save solo channel method with channel selected as input
    }
    @FXML private void saveSoloButtonAction2() throws IOException{ //methods repeated with other channels
        channelSelected = 2;
        saveSoloChannelButtonMethod(channelSelected);
    }
    @FXML private void saveSoloButtonAction3() throws IOException{
        channelSelected = 3;
        saveSoloChannelButtonMethod(channelSelected);
    }
    @FXML private void saveSoloButtonAction4() throws IOException{
        channelSelected = 4;
        saveSoloChannelButtonMethod(channelSelected);
    }
    
    public void pressHelpButton(ActionEvent event) throws Exception {               
    try {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HelpScreen.fxml")); 
        //create new FXML loader with HelpScreen.fxml as it's resource
        Parent root1 = (Parent) fxmlLoader.load();  //load root of parent fxml loader
        Stage stage = new Stage();                  //create a new stage
        stage.setScene(new Scene(root1));           //set scene of stage to be new document
        stage.setMaxWidth(600);                     //set max width to 600 pixels
        stage.setMaxHeight(500);                    //set max height to 500 pixels
        stage.show();                               //show stage
    } catch(Exception e) {
        e.printStackTrace();                        //print exception stack trace if failed
    }
    }
    
    public void pressAboutButton(ActionEvent event) throws Exception {               
    try {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AboutScreen.fxml"));
        //create new FXML loader with AboutScreen.fxml as it's resource
        Parent root1 = (Parent) fxmlLoader.load(); //load root of parent fxml loader
        Stage stage = new Stage();                 //create a new stage
        stage.setScene(new Scene(root1));          //set scene of stage to be new document
        stage.setMaxWidth(600);                    //set max width to 600 pixels
        stage.setMaxHeight(600);                   //set max height to 500 pixels
        stage.show();                              //show stage
    } catch(Exception e) {
        e.printStackTrace();                       //print exception stack trace if failed
    }
}
    
    //* Reset buttons in save drop down menu activated here*//
    @FXML public void resetAllAction(ActionEvent event) throws IOException{
        resetConfirmAlert(); //calls reset confirm alert
    }
    @FXML private void resetButtonAction1(ActionEvent event) throws IOException{
    channelSelected = 1;                            //sets channel selected to appropriate channel
    resetSoloChannelButtonMethod(channelSelected);  //resets solo channel based on channels selected
    }
    @FXML private void resetButtonAction2(ActionEvent event) throws IOException{ //methods repeated
    channelSelected = 2;
    resetSoloChannelButtonMethod(channelSelected);
    }
    @FXML private void resetButtonAction3(ActionEvent event) throws IOException{
    channelSelected = 3;
    resetSoloChannelButtonMethod(channelSelected);
    }
    @FXML private void resetButtonAction4(ActionEvent event) throws IOException{
    channelSelected = 4;
    resetSoloChannelButtonMethod(channelSelected);
    }
    
    
    @FXML private void setDirectoryButtonAction(ActionEvent event){
    saveMenuSetFile(); //call save menu set file method
    }
    
    @FXML private void exitMenuButtonAction(ActionEvent event) throws IOException{
    exitButtonMethod(); //call exit button 
    }
    
    
    /*Splash Screen variables*/
    @FXML
    private Label progress; //create new FXML label 
    
    public static Label label; //create new public static label (so it can be referenced by preloader)
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        label = progress; //switch variables over
        
    }    
    
}
