/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadenzanea;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.application.Preloader;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


public class CadenzaPreloader extends Preloader {
    
    private Stage preLoaderStage; //create new stage variable with no initialisation
    private Scene scene;          //create new scene variable with no initialisation
    
    public CadenzaPreloader(){ //blank constructor
        
    }
    
    @Override //override initilisation to load the splash screen first
    public void init() throws Exception{
        Parent root1 = FXMLLoader.load(getClass().getResource("SplashScreenLoading.fxml")); //get splash screen FXML
        scene = new Scene(root1); //load the scene as the fxml
    }
    
    @Override //override start method 
    public void start(Stage primaryStage) throws Exception {  //input stage variable
        this.preLoaderStage = primaryStage; //initialise local preLoaderStage variable as primary stage
        Image icon = new Image(getClass().getResource("logo.png").toURI().toString()); //get logo
        primaryStage.getIcons().add(icon);  //Add image icon to clas
        primaryStage.setMaxWidth(655); //set max height and width
        primaryStage.setMaxHeight(390);
        preLoaderStage.setScene(scene); //set the preloader stage with the splash screen scene
        preLoaderStage.initStyle(StageStyle.UNDECORATED); //set style as undecorated (no surrounding window)
        preLoaderStage.show(); //show splash screen stage
    }
    
    @Override //override handle application notification method
    public void handleApplicationNotification(Preloader.PreloaderNotification info){ //input preloader info
        if(info instanceof ProgressNotification){ //if there is an instance of a progress notification in info
            FXMLDocumentController.label.setText("Loading "+((ProgressNotification)info).getProgress()+"%");
            //set static label text to loading progress value
        }
    }
    @Override //override state change notification handler
    public void handleStateChangeNotification(Preloader.StateChangeNotification info){ //input info
        StateChangeNotification.Type type = info.getType(); //get type of info
        switch(type){ //switch statement on type
            case BEFORE_START: //if type is BEFORE_START (constant)
                preLoaderStage.hide(); //hide preloader stage
                break; //break switch statement
        }
    }
}
