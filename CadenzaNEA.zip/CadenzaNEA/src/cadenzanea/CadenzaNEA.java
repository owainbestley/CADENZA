
package cadenzanea;

//call imports for Java FX objects
import com.sun.javafx.application.LauncherImpl;
import javafx.application.Application;
import javafx.application.Preloader;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;


public class CadenzaNEA extends Application { //Extends application class
    private static final int COUNT_LIMIT = 500000; 
    //create a count limit constant to use in the initialiser
    
    //creates main program window
    @Override //Override start method
    public void start(final Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml")); 
        //Create new parent root using FXMLDocument.fxml
        
        Image icon = new Image(getClass().getResource("logo.png").toURI().toString());
        //Add image icon to class
        
        stage.getIcons().add(icon);//add icon to stage
        
        Scene scene = new Scene(root); //create new scene with root
        
        stage.setScene(scene); //set the scene onto the stage
        
        stage.setTitle("Cadenza"); //set the stage title
        
        stage.setMaxWidth(655); //set stage max width and height
        stage.setMaxHeight(490);
       
        stage.show();  //show stage
        
        
    }
    
    //initialises the progress meter value
    @Override
    public void init() throws Exception{
        
        
        for(int i = 0; i<COUNT_LIMIT;i++){ //for 0 to count limit constant
            double progress = (100*i)/COUNT_LIMIT ; //progress is 100 * i divided by count limit
            LauncherImpl.notifyPreloader(this, new Preloader.ProgressNotification(progress));
            //notify preloader with new progress value
        }
    }

    //uses launcher with both the main class and preloader class to create splash screen then load application
    public static void main(String[] args) {
        LauncherImpl.launchApplication(CadenzaNEA.class,CadenzaPreloader.class,args);
        
    }
    
}
