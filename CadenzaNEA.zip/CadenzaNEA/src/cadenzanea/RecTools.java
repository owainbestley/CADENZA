/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadenzanea;


import java.io.*;
import java.util.Arrays;
import javax.sound.sampled.*;




/**
 *
 * @author owain
 */
public class RecTools{
//sets up variables for recording but doesn't intialise them, allows them to be set up later
    private AudioFormat audioFormat;
    private TargetDataLine dataLine;
    private ByteArrayOutputStream recordedBytes;
    private String fileName;
    private File audioOutput;
//boolean value used to break loop in recording and playback   
    private boolean recordingRunning = false;
    boolean playbackRunning;
    
//variables associated to channel selection
    private int channel = 1;
    private int activeTargetChannel;

//arrays associated to recording (1-4 and final mix)
    byte[] tempByteArray1 = new byte[0];
    byte[] tempByteArray2 = new byte[0];
    byte[] tempByteArray3 = new byte[0];
    byte[] tempByteArray4 = new byte[0];
    byte[] mixedByteArray;
    
//post processing values
    float pan = 0;
    float gain;
    
//playback buffer and source data line which feeds into it
    byte tempBuffer[] = new byte[10000];
    SourceDataLine sourceDataLine;
    
    
// getter method for audio format 
//variables related to audio format are defined
//constructs and returns a new audio format
    AudioFormat getAudioFormat() {
        float sampleRate = 41100; //44.1KHz (standard recording sample rate)
        int bitDepth = 16; //CD quality standard bit depth
        int channels = 2; //Stereo
        boolean signed = true; 
        boolean bigEndian = false; //Data ordered in little endian
        return new AudioFormat(sampleRate,bitDepth,channels,signed,bigEndian);
    }
    
    //void used to reset values in program
    void intialiseValues(){
    fileName = null; //changes file name saved to null
    
    audioOutput = null; //saved file name changed to null
    
    recordingRunning = false; //resets both boolean values to make
    
    playbackRunning = false; //sure recording and playback both aren't running
    
    recordedBytes = null; //resets bite array output stream
    
    dataLine = null; //resets target data line
    
    channel = 1; //resets channel selection to 1
    
    tempByteArray1 = new byte[0]; //resets all 4 channels to null
    tempByteArray2 = new byte[0]; //using a new array with no entries 
    tempByteArray3 = new byte[0]; //to replace an existing one
    tempByteArray4 = new byte[0];
    }
    
    //getters and setters for Pan and gain Values
    float getPanValue(){
        return pan;
    }
    void setPanValue(float change){
        this.pan = change;
    }
    
    float getGainValue(){
        return gain;
    }
    void setGainValue(float change){
        this.gain = change;
    }
    
    //uses the same technique in intialise constructors to reset a single array
    void resetSingleArray(){
        byte[] activeArray = getActiveArray(activeTargetChannel);
        //uses method to assign the array selected to a new array
        activeArray = new byte[0]; //resets the array
    }
    
    //more getters and setters for various variables
    void setFileName(String newName){
        this.fileName = newName;
    }
    byte[] getMixedByteArray(){
        return mixedByteArray;
    }
    
    String getFileName(){
        return this.fileName;
    }
    void setChannel(int channelNo){
        this.channel = channelNo;
    }
    int getChannel(){
        return channel;
    }
    void setActiveChannel(int channelNo){
        this.activeTargetChannel = channelNo;
    }
    
    //used to find which channel is active/selected
    byte[] getActiveArray(int activeChannel){
        activeChannel = this.activeTargetChannel;
        byte[] targetArray = tempByteArray1; //sets up default case for returns
        if(activeChannel == 1){ //selection statements to find which channel is active
            targetArray = this.tempByteArray1; //array assigned based on active channel
        }
        else if(activeChannel == 2){
            targetArray = this.tempByteArray2;
        }
        else if(activeChannel == 3){
            targetArray = this.tempByteArray3;
        }
        else if(activeChannel == 4){
            targetArray = this.tempByteArray4;
        }
        return targetArray; //return the chosen array
    }
    
    //getter for getFile (audioOutput) which returns the filename with .wav
    File getFile(){
        return this.audioOutput;
    }
    //used to create the full file name
    File setFileWithFileName(){
        audioOutput = new File(fileName+".wav"); 
    //concats the filename with the file identifier
        return this.audioOutput;
    //return the file name
    }
    
    //used to find the target data line that will be used for recording
    public TargetDataLine getDataLine() throws LineUnavailableException{
        
        audioFormat = getAudioFormat(); //gets the audio format
        
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, audioFormat);
        //gets the info from the target dataline (like if line is avaliable etc)
        
        if (!AudioSystem.isLineSupported(info)) {
            throw new LineUnavailableException("Format Unsupported");
        }  
        //if line isn't supported then the system returns that the format is unsupported
        
        final TargetDataLine dataLine = AudioSystem.getTargetDataLine(audioFormat);
        //creates a final data line which has been verified
        AudioSystem.getLine(info);
        return dataLine; //returns final data line
    }
    
    
    //method used to start recording
    public void startRec() throws Exception{
        try{
        audioFormat = getAudioFormat(); //gets the audio format
        dataLine = getDataLine();       //gets the data line
        
        dataLine.open(audioFormat); //opens the data line, using audio format
        dataLine.start();           //starts capturing audio
        
        byte[] buffer = new byte[dataLine.getBufferSize()]; //initialises buffer to record data from
        int bytesRead = 0;                                  //used to keep the byte of data read
 
        recordedBytes = new ByteArrayOutputStream();        //initialises byte array output stream created in first block
        recordingRunning = true;                            //sets recording running boolean to true
        
        while (recordingRunning) {                                //while recording is running
            bytesRead = dataLine.read(buffer, 0, buffer.length); //reads the byte in data line buffer
            recordedBytes.write(buffer, 0, bytesRead);          //writes byte to byte array output stream
        }
        }catch(LineUnavailableException ex) {} //catches exception
        
        byte[] newByteLineData = recordedBytes.toByteArray(); //assigns byteArray
        //newByteLineData = setPan(pan,newByteLineData);        //sets pan value of byte array to pan
       // newByteLineData = adjustVolume(newByteLineData,gain); //adjusts volume of byte array to gain
        
            if(channel == 1){                                                          //series of if statements to save byte array to one of four temp byte array (the channels)
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream( ); //creates new byte array output stream
                    outputStream.write( tempByteArray1 );                              //writes original data to prevent loss of data already in array
                    outputStream.write( newByteLineData );                             //writes new data directly after , acting as concatenation 
                    tempByteArray1 = outputStream.toByteArray( );                      //writes the new output stream (converted to byte array) to the temp array
            }if(channel == 2){
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
                    outputStream.write( tempByteArray2 );
                    outputStream.write( newByteLineData );
                    tempByteArray2 = outputStream.toByteArray( );                    
            }if(channel == 3){
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
                    outputStream.write( tempByteArray3 );
                    outputStream.write( newByteLineData );
                    tempByteArray3 = outputStream.toByteArray( );                    
            }if(channel == 4){
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
                    outputStream.write( tempByteArray4 );
                    outputStream.write( newByteLineData );
                    tempByteArray4 = outputStream.toByteArray( );
            } 
    }
    
    public void recordPause(){
        recordingRunning = false;
        if (dataLine != null) {
        dataLine.flush();
        dataLine.close();
        }
        
    }
    
    //method to stop recording
    public void recordStop(){ 
        recordingRunning = false; //boolean variable that breaks the while loop
        if (dataLine != null) {  //if the target data line isn't empty
            dataLine.flush();    //flush the line and remove any remaining data in it   
            dataLine.close();    //close the line and prevent any more data from being captured and written
		}
        
        
    }
    
    //used to save only one channel
    public void recordSaveOnlyChannelOne(File wavFile,int arrayNo) throws IOException { //inputs the wavFile name and the number of the byte array to save
        byte[] lineData = getActiveArray(activeTargetChannel);                          //take audio from an array and save it into a new byte array
        if (lineData == null){}                                                         //if the array is empty, do nothing
        
        else{
        ByteArrayInputStream bais = new ByteArrayInputStream(lineData); //otherwise create a new byte array input stream with the array
        AudioInputStream AIS = new AudioInputStream(bais, audioFormat,lineData.length / audioFormat.getFrameSize()); 
        //use an audio input stream using the byte array input stream, formatting it to the audio format
        //Then writing it to a file which is the length of the array divided by the frame size (2 bytes)
        
        AudioSystem.write(AIS, AudioFileFormat.Type.WAVE, wavFile); //use the audiosystem.write function to write the ais to the wavFile using the wav file format
        
        AIS.close();           //close the audio input stream
        recordedBytes.close(); //close the byte array output stream
        }
    }
    
    //used to save all channels to a single file (merge)
    public void recordSave(File wavFile) throws IOException { //take the wavFile as input
        combineAudio();                     //call the audio combine algorithm 
        byte[] lineData = mixedByteArray;   //then store the combined audio into a new byte array
        
      
        ByteArrayInputStream bais = new ByteArrayInputStream(lineData); //create a new byte array input stream with the array
        AudioInputStream AIS = new AudioInputStream(bais, audioFormat,lineData.length / audioFormat.getFrameSize());
        //use an audio input stream using the byte array input stream, formatting it to the audio format
        //Then writing it to a file which is the length of the array divided by the frame size (2 bytes)
 
        AudioSystem.write(AIS, AudioFileFormat.Type.WAVE, wavFile); //use the audiosystem.write function to write the ais to the wavFile using the wav file format
 
        AIS.close();             //close the audio input stream
        recordedBytes.close();   //close the byte array output stream
        
    }
    
    public byte[] setPan(float panPercentage,byte[] rawData) throws LineUnavailableException, IOException{   //take pan percentage and raw data byte array as input 
        
    DataLine.Info info = new DataLine.Info(SourceDataLine.class, audioFormat); //retrieve dataline info
    
    ByteArrayInputStream bais = new ByteArrayInputStream(rawData); //create a new byte array input stream with the array
    AudioInputStream AIS = new AudioInputStream(bais, audioFormat,rawData.length / audioFormat.getFrameSize());
    //use an audio input stream using the byte array input stream, formatting it to the audio format
    //Then writing it to a file which is the length of the array divided by the frame size (2 bytes)
        
    SourceDataLine dataLine = (SourceDataLine) AudioSystem.getLine(info); 
    //find a new source data line by casting target data line
    

    dataLine.open(audioFormat); //open the line
    dataLine.start(); //start recording data

    FloatControl pan = (FloatControl) dataLine.getControl(FloatControl.Type.PAN); //Create a new float control by getting pan control from line

    pan.setValue(panPercentage); //set the panning value to pan percentage value

    int BUFFER_SIZE = 4096; //setup buffer size 

    byte[] buffer = new byte[BUFFER_SIZE]; //create a buffer byte array with the buffer size

    int read = -1; //sets read to -1 to signify null value

    while((read = AIS.read(buffer)) != -1){ //while the byte read in buffer isn't null
        dataLine.write(buffer, 0, read); //write the new panned buffer data
    }

    dataLine.drain(); //drain line of any remaining data
    dataLine.close(); //close line
    return buffer;    //return the buffer array
    }
    
   
   
   
    private byte[] mixBuffers(byte[] inputBuffer1, byte[] inputBuffer2) { //take input of two byte arrays
    int combinedBufferLength = 0;                                         //initialise the combined buffer length as 0
    combinedBufferLength += Math.max(inputBuffer1.length, inputBuffer2.length); //add the max length of the input arrays to combined length
    
    byte[] array = new byte[combinedBufferLength]; //create a new array which is the size of the combined buffer
    byte[] bufferA = Arrays.copyOf(inputBuffer1, combinedBufferLength); //create copies of the arrays with the original data input into them
    byte[] bufferB = Arrays.copyOf(inputBuffer2, combinedBufferLength); //but with the combined length of the array
    
    for (int i=0; i<array.length; i+=2) { //for the length of the array
        short buf1A = bufferA[i+1];       //find the two bytes which need to be altered 
        short buf2A = bufferA[i];         //(bytes are in pairs so i and i+1)
        buf1A = (short) ((buf1A & 0xff) << 8); //bitwise shift the second byte 8 times to make it even to regular byte bases and cast it to short
        buf2A = (short) (buf2A & 0xff);        //cast byte to short

        short buf1B = bufferB[i+1]; //repeat steps above but on the other array
        short buf2B = bufferB[i];
        buf1B = (short) ((buf1B & 0xff) << 8);
        buf2B = (short) (buf2B & 0xff);

        short buf1C = (short) (buf1A + buf1B); //add the two bytes together
        short buf2C = (short) (buf2A + buf2B);

        short res = (short) (buf1C + buf2C); //add the two sets into a new a resultant short

        array[i] = (byte) res;          //cast short result to byte and store in the array
        array[i+1] = (byte) (res >> 8); // cast result, bitwise shifted 8 times back to the  original base for i+1, to byte and store in array
    }

    return array; //return the new array
    }
    
    public void combineAudio(){
        byte[] combinationOne = mixBuffers(tempByteArray1,tempByteArray2); //combines all the arrays together
        byte[] combinationTwo = mixBuffers(tempByteArray3,tempByteArray4);
        byte[] channelsCombinedAll = mixBuffers(combinationOne,combinationTwo);
        
        adjustVolume(channelsCombinedAll,-5); //adjusts the volume
        distortSoftClip(channelsCombinedAll); //adds distortion to combined byte arrays
        adjustVolume(channelsCombinedAll,-10); //attenuates overall volume
        
        mixedByteArray = channelsCombinedAll; //assigns new combined array to mixed byte array
        
    }
    
    public void distortSoftClip(byte[] buffer) { //takes byte buffer as input
     double th=1.0/3.0;                     //sets threshold to 1/3
     double multiplier = 0.00025;           //distortion multiplier 
     double out = 0.0;                      //output volume set to 0dB
     
     for(int i=0;i<buffer.length;i++){              //for the length of the array
        double in = multiplier*(double)buffer[i];   //in is assigned by taking the info held in the buffer 
                                                    //and multiply it by the multiplier
                                                    
        double absIn = java.lang.Math.abs(in); //gets the absolute value of in
        
        if(absIn<th){                       //if the value is higher than the threshold
            out=(buffer[i]*2*multiplier);   //take the value of the buffer
                                            //multiply by 2 and then by the multiplier
        }
        
        else if(absIn<2*th){                        //if the value is below 2x the threshold
            if(in>0)out= (3-(2-in*3)*(2-in*3))/3;   //and if the output is above 0 apply this level of distortion
            else if(in<0)out=-(3-(2-absIn*3)*(2-absIn*3))/3; //if it is below 0, inverse this by adding - to the start
        }
        else if(absIn>=2*th){ //if the value is higher than or equal to the threshold
            if(in>0)out=1;    //output is clipped
            else if(in<0)out=-1; //if not do the inverse
        }
        
        buffer[i] = (byte)(out/multiplier); //cast out to byte and then divide by multiplier
    }
    }
    
    private byte[] adjustVolume(byte[] audioSamples, float volume) { //insert a byte array and float value
        byte[] array = new byte[audioSamples.length];                //create a new byte array based on input arrays length
        for (int i = 0; i < array.length; i+=2) { //for array length
            short buf1 = audioSamples[i+1];       // convert byte pair to short 
            short buf2 = audioSamples[i];

            buf1 = (short) ((buf1 & 0xff) << 8); //bitwise buffer1 8 places then convert to short
            buf2 = (short) (buf2 & 0xff);        //convert to short

            short res = (short) (buf1 + buf2); //add the buffers together and store as result
            res = (short) (res * volume);      //multiply result by volume and store as short

            // convert back to bytes
            array[i] = (byte) res;
            array[i+1] = (byte) (res >> 8);

        }
        return array; //return the finished array
    }    
    
   
    
     
    

    
    
    
    
    public SourceDataLine srcLineMixedByte() throws LineUnavailableException{

        DataLine.Info dataLineInfo =new DataLine.Info(SourceDataLine.class,audioFormat); //retrieves data line info
        SourceDataLine sourceDataLine =(SourceDataLine)AudioSystem.getLine(dataLineInfo);//creates new sourcedataline with data line info
        
        return sourceDataLine; //retrun source data line
    }
    
    
    
    public void startPlayback(AudioFormat audioFormat) throws LineUnavailableException, IOException{
      combineAudio();                   //call combined audio function to merge arrays
      byte[] lineData = mixedByteArray; //set mixed byte array as lineData
      
      ByteArrayInputStream bais = new ByteArrayInputStream(lineData); //create new byte array input stream with line data
      AudioInputStream AIS = new AudioInputStream(bais, audioFormat,mixedByteArray.length / audioFormat.getFrameSize());
      //use an audio input stream using the byte array input stream, formatting it to the audio format
      //Then writing it to a file which is the length of the array divided by the frame size (2 bytes)
      
      sourceDataLine = srcLineMixedByte(); //source data line is found using method
      sourceDataLine.open(audioFormat);    //open line using the audio format 
      sourceDataLine.start();              //start capturing data from source line 
      playbackRunning = true;              //set boolean playback running to be true
      int cnt;
      //Keep looping until the input read method
      // returns -1 for empty stream or the
      // user clicks the Stop button causing
      // a switch from true to false
      while((cnt = AIS.read(tempBuffer,0,tempBuffer.length)) != -1 && playbackRunning == true){
        if(cnt > 0){
          //write data to the internal buffer of
          //the data line where it will be
          //delivered to the audio output.
          sourceDataLine.write(tempBuffer, 0, cnt);
        }
        
      }
    }
    
    public void stopPlayback(){
        playbackRunning = false;        //set playback running to false
        if (sourceDataLine != null) {   //if line isn't empty
            sourceDataLine.flush();     //flush the line
            sourceDataLine.close();     //close the line
		}
    }
    
   
    

    
}


    
    


